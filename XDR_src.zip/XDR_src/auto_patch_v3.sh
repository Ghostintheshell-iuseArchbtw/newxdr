#!/usr/bin/env bash
set -euo pipefail

# auto_patch_v3.sh — Arch/Linux-friendly patcher (idempotent, no awk warnings)
# Usage:
#   ./auto_patch_v3.sh [--repo-root PATH] [--dry-run] [-v]

REPO_ROOT="${PWD}"
DRY_RUN=0
VERBOSE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo-root) REPO_ROOT="$2"; shift 2;;
    --dry-run)   DRY_RUN=1; shift;;
    -v|--verbose) VERBOSE=1; shift;;
    -h|--help)
      cat <<USAGE
Usage: $0 [--repo-root PATH] [--dry-run] [-v]
Patches minifilter & WFP sources to publish events. Creates .bak backups.
USAGE
      exit 0;;
    *) echo "Unknown arg: $1" >&2; exit 2;;
  esac
done

log()  { echo "[$(date +%H:%M:%S)] $*"; }
vlog() { [[ $VERBOSE -eq 1 ]] && echo "[$(date +%H:%M:%S)] $*"; }

apply_or_show() { # $1=file $2=tmp
  if [[ $DRY_RUN -eq 1 ]]; then
    diff -u "$1" "$2" || true
    rm -f "$2"
  else
    cp -n "$1" "$1.bak" 2>/dev/null || true
    mv "$2" "$1"
    log "patched: $1  (backup: $1.bak)"
  fi
}

find_dir_or_die() {
  local name="$1"
  local path
  path="$(find "$REPO_ROOT" -maxdepth 3 -type d -name "$name" | head -n1 || true)"
  [[ -n "$path" ]] || { echo "Missing directory: $name (under $REPO_ROOT)" >&2; exit 1; }
  printf "%s\n" "$path"
}

MINIDIR="$(find_dir_or_die xdrfs_minifilter)"
WFPDIR="$(find_dir_or_die xdrwfp_callout)"
SHAREDDIR="$(find_dir_or_die shared)"

first_vcxproj() { find "$1" -maxdepth 1 -type f -name '*.vcxproj' | head -n1; }
MINIPROJ="$(first_vcxproj "$MINIDIR" || true)"
WFPPROJ="$(first_vcxproj "$WFPDIR" || true)"

# ----------------- helpers ----------------------------------------------------
c_insert_include_once() { # $1=file $2=line_to_insert
  local f="$1" inc="$2"
  grep -Fq "$inc" "$f" && { vlog "include already present in $(basename "$f")"; return 0; }
  local tmp; tmp="$(mktemp)"
  awk -v INC="$inc" '
    BEGIN{last=0}
    { if ($0 ~ /^[[:space:]]*#[[:space:]]*include\b/) last=NR; lines[NR]=$0 }
    END{
      if (last>0) {
        for(i=1;i<=last;i++) print lines[i];
        print INC;
        for(i=last+1;i<=NR;i++) print lines[i];
      } else {
        print INC;
        for(i=1;i<=NR;i++) print lines[i];
      }
    }
  ' "$f" >"$tmp"
  apply_or_show "$f" "$tmp"
}

c_inject_after_brace_once() { # $1=file $2=function_name_regex $3=payload
  local f="$1" fnre="$2" payload="$3"
  # idempotence check
  if grep -Fq "$(echo "$payload" | head -n1)" "$f"; then
    vlog "payload already present for $fnre in $(basename "$f")"
    return 0
  fi
  local tmp; tmp="$(mktemp)"
  awk -v FNRE="$fnre" -v PAYLOAD="$payload" '
    BEGIN{arm=0; injected=0}
    {
      print
      if ($0 ~ FNRE) arm=1
      else if (arm==1 && $0 ~ /\{/) { print PAYLOAD; arm=0; injected=1 }
    }
    END{}
  ' "$f" >"$tmp"
  if cmp -s "$f" "$tmp"; then rm -f "$tmp"; else apply_or_show "$f" "$tmp"; fi
}

proj_add_itemgroup_entries() { # $1=proj; rest: xml lines to add inside new ItemGroup
  local proj="$1"; shift
  [[ -n "$proj" && -f "$proj" ]] || { vlog "no .vcxproj present — skipping $(basename "$proj")"; return 0; }
  local joined=""
  local all_present=1
  for x in "$@"; do
    joined+="    $x"$'\n'
    local pat
    pat="$(sed -n 's/.*Include="\([^"]\+\)".*/\1/p' <<<"$x" | tr -d '\n')"
    [[ -z "$pat" ]] || grep -Fq "Include=\"$pat\"" "$proj" || all_present=0
  done
  if [[ $all_present -eq 1 ]]; then vlog "all entries present in $(basename "$proj")"; return 0; fi
  local tmp; tmp="$(mktemp)"
  awk -v BODY="$joined" '
    /<\/Project>/ && !added {
      print "  <ItemGroup>"
      printf "%s", BODY
      print "  </ItemGroup>"
      added=1
    }
    { print }
  ' "$proj" >"$tmp"
  apply_or_show "$proj" "$tmp"
}

xml_add_if_missing() { # $1=proj $2=needle_regex $3=new_xml_snippet
  local proj="$1" needle="$2" snippet="$3"
  [[ -n "$proj" && -f "$proj" ]] || { vlog "no .vcxproj present — skipping $(basename "$proj")"; return 0; }
  if grep -Eq "$needle" "$proj"; then
    vlog "xml already present in $(basename "$proj")"
    return 0
  fi
  local tmp; tmp="$(mktemp)"
  awk -v SNIP="$snippet" '
    /<\/Project>/ && !added { print "  " SNIP; added=1 }
    { print }
  ' "$proj" >"$tmp"
  apply_or_show "$proj" "$tmp"
}

# ----------------- 1) Minifilter source patching ------------------------------
XDRFS_C="$MINIDIR/xdrfs.c"
if [[ -f "$XDRFS_C" ]]; then
  c_insert_include_once "$XDRFS_C" '#include "xdrfs_wire.h"'
  c_inject_after_brace_once "$XDRFS_C" '^[[:space:]]*XdrfsPostCreate[[:space:]]*\\([^)]*\\)[[:space:]]*\\{' \
'    if (NT_SUCCESS(Data->IoStatus.Status)) { XdrfsWire_OnPostCreate(Data, FltObjects); }'
  c_inject_after_brace_once "$XDRFS_C" '^[[:space:]]*XdrfsPostWrite[[:space:]]*\\([^)]*\\)[[:space:]]*\\{' \
'    if (NT_SUCCESS(Data->IoStatus.Status)) { XdrfsWire_OnPostWrite(Data, FltObjects); }'
  c_inject_after_brace_once "$XDRFS_C" '^[[:space:]]*XdrfsPostSetInformation[[:space:]]*\\([^)]*\\)[[:space:]]*\\{' \
'    if (NT_SUCCESS(Data->IoStatus.Status)) { XdrfsWire_OnPostSetInformation(Data, FltObjects); }'
else
  log "skip: $XDRFS_C not found"
fi

# ----------------- 2) WFP classify publisher injection -----------------------
for CAND in "$WFPDIR/xdrwfp.c" "$WFPDIR/classify.c" "$WFPDIR/callout.c"; do
  [[ -f "$CAND" ]] || continue
  c_inject_after_brace_once "$CAND" 'AleAuthConnectV4[^)]*\\)[[:space:]]*\\{' \
'#ifdef XDR_AUTOPATCH
    XdrwfpWire_PublishConnectV4(inFixedValues, inMetaValues, XDR_NET_MONITOR);
#endif'
done

# ----------------- 3) Optional project (.vcxproj) updates ---------------------
proj_add_itemgroup_entries "$MINIPROJ" \
  '<ClInclude Include="xdrfs_publish.h" />' \
  '<ClInclude Include="xdrfs_wire.h" />' \
  '<ClCompile Include="xdrfs_publish.c" />' \
  '<ClCompile Include="xdrfs_wire.c" />'

xml_add_if_missing "$MINIPROJ" \
  '<AdditionalIncludeDirectories>.*\.\.\\\.\.\\shared' \
  '<PropertyGroup>
    <AdditionalIncludeDirectories>..\..\shared;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  </PropertyGroup>'

proj_add_itemgroup_entries "$WFPPROJ" \
  '<ClCompile Include="xdrwfp_wire.c" />'

xml_add_if_missing "$WFPPROJ" \
  '<AdditionalIncludeDirectories>.*\.\.\\\.\.\\shared' \
  '<PropertyGroup>
    <AdditionalIncludeDirectories>..\..\shared;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  </PropertyGroup>'

log "Done. Review *.bak if needed. Re-run with -v for details."
