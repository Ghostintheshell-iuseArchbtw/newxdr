$ErrorActionPreference = "Stop"
param([string]$Dest = "$PWD\xdr_project_src")

$parts = Get-ChildItem -File -Path "$PSScriptRoot\parts" -Filter "xdr_src_full.part*.zip" | Sort-Object Name
if ($parts.Count -eq 0) { throw "No parts found" }

Write-Host "Assembling $($parts.Count) parts..."
$outZip = Join-Path $PSScriptRoot "xdr_src_full.zip"
if (Test-Path $outZip) { Remove-Item -Force $outZip }

$fsOut = [System.IO.File]::OpenWrite($outZip)
foreach ($p in $parts) {
  $bytes = [System.IO.File]::ReadAllBytes($p.FullName)
  $fsOut.Write($bytes, 0, $bytes.Length)
}
$fsOut.Close()

# Verify SHA-256
$expected = "770893d9aa2c5ddb33a7789c6804c6f8042c18fd1eb7e4981f1efcddf3857ca1"
$hash = Get-FileHash -Algorithm SHA256 $outZip
if ($hash.Hash.ToLower() -ne $expected.ToLower()) {
  throw "SHA-256 mismatch! expected=$expected got=$($hash.Hash.ToLower())"
}
Write-Host "Checksum OK: $expected"

# Extract
if (-not (Test-Path $Dest)) { New-Item -ItemType Directory -Force -Path $Dest | Out-Null }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory($outZip, $Dest, $true)

Write-Host "Done. Extracted to $Dest"
